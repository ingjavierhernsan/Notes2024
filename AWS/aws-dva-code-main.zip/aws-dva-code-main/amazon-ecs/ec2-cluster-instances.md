#!/bin/bash
echo ECS_CLUSTER=your_cluster_name >> /etc/ecs/ecs.config